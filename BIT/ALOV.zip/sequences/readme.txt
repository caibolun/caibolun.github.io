Qualitative results for proposed BIT, compared with top-performing ICF, DSST, KCF
http://caibolun.github.io/BIT
BIT--Red
ICF--Green
DSST--Blue
KCF--Pink